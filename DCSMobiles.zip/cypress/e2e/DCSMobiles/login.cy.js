describe('DCSMobiles Login', () => {
    beforeEach(() => {
        cy.visit('http://localhost/DCSMobiles/admin/admin-login.php')
    })

    it('should display an error message for invalid credentials', () => {
        cy.get('input[name="username"]').type('invalid@example.com');
        cy.get('input[name="password"]').type('wrongpassword');
        cy.get('form').submit();
        cy.get('.alert').should('contain', 'Invalid username or password');
    });

    it('should redirect to index.php for valid credentials', () => {
        cy.get('input[name="username"]').type('admin@gmail.com');
        cy.get('input[name="password"]').type('123');
        cy.get('form').submit();
        cy.url().should('include', '/all-products.php');
    });

})