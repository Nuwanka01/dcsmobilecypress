describe('Add Product Form', () => {
    beforeEach(() => {
        cy.visit('http://localhost/DCSMobiles/admin/admin-login.php');
        cy.get('input[name="username"]').type('admin@gmail.com');
        cy.get('input[name="password"]').type('123');
        cy.get('form').submit();
        cy.url().should('include', '/all-products.php');
        cy.visit('http://localhost/DCSMobiles/admin/add-product.php');
    });

    it('should successfully add a new product with all required information', () => {
        cy.get('input[name="product_name"]').type('New Product');
        cy.get('input[name="product_price"]').type('99.99');
        cy.get('input[name="product_image"]').attachFile('test-image.jpg');
        cy.get('input[type="submit"]').click();
        cy.get('.alert').should('contain', 'New product created successfully');
    });

    it('should display an error message when required fields are missing', () => {
        cy.get('input[type="submit"]').click();
        cy.get('input[name="product_name"]').then($input => {
            cy.wrap($input).should('have.attr', 'required');
        });
        cy.get('input[name="product_price"]').then($input => {
            cy.wrap($input).should('have.attr', 'required');
        });
        cy.get('input[name="product_image"]').then($input => {
            cy.wrap($input).should('have.attr', 'required');
        });
        cy.url().should('include', '/add-product.php');
    });
});
